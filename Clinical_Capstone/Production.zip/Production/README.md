# Running the model comparison tool

Once all scripts are run, in terminal submit the following:

`` bokeh serve --show Production/company_comparison_tool.py``